To add a skin override, you need to create a json file:
assets/appearance/skins/<name>.json

This file needs to have the following contents: 

{
	"uuid": "772eb47b-a24e-4d43-a685-6ca9e9e132f7",
	"model": "slim",
	"texture": "transparent_ari"
}

"uuid" must match the desired player's uuid.
You can find your UUID on  your https://namemc.com/ profile page or in the server console logs when you log in.

"model" must be "slim" or "wide".

"texture" must match the file name of your skin.
The texture should be stored at:
assets\appearance\textures\entity\player\<model>\<skin_filename>.png